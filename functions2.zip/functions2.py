# -*- coding: utf-8 -*-
"""
Created on Mon Feb 26 13:24:46 2024

@author: blanchai4714
"""
import functions as fun
def main():
    # ask for number of tests
    num_tests = int(input("How many tests do you have to enter: "))
    
    #ask user to enter names
    
    # create a list with test names
    tests = []
    for x in range(num_tests):
        
        test_name = input("please enter the tests name: ")
        
        tests.append(test_name)
    
    
    stu_num = int(input("Enter the number of students: "))
    
    students = []
    
    for x in range(stu_num):
        student = []
        stu_name = input("Enter student name: ")
        student.append(stu_name)
        # Enter score for each test
        for test in tests:
            
            print("Enter score for", test)
            
            score = float(input())
            student.append(score)
        
        scores = student[1:]
        avg = sum(scores)/len(scores)
        # append to student list
        student.append(avg)
        
        # get letter grade
        grade = fun.get_letter_grade(avg)
        
        student.append(grade)
        
        students.append(student)
    print(students)
            
            
        
        
    
    
    
    
    
    
    
    
    
if __name__ == "__main__":
    
    main()