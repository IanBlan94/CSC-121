# -*- coding: utf-8 -*-
"""
Created on Mon Feb 26 14:06:36 2024

@author: blanchai4714
"""

students = [["jon", 78, 98, 76, "a"],["kim", 98, 45, 65, "a"]]

# header row

#get number of tests
tests = ["quiz1", "quiz2"]

print(f'{"Name":<15}', end=" ")
for test in tests:
    
    print(f'{test:<10}', end="")
print(f'{"Avg:<7"}{"Grade"}')

for student in students:
    # iterate over inner list
    for i in student:
        
        print(f'{i:<10}', end="")
    print()


