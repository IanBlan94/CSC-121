# -*- coding: utf-8 -*-

"""
1. ask user for number of students
2. ask the user for number of tests
3.ask for first student name
4. ask for first test name and score
5. after entries, move to next student
6. calculate average for each student and determine grade
6. display results

"""

def get_letter_grade(score):
    if score >= 90:
        grade = "A"
    elif score >= 80:
        grade = "B"
    elif score >= 70:
        grade = "C"
    elif score >= 60:
        grade = "D"
    else:
        grade = "F"
    return grade
    